1. install the requirements.txt
by  using "pip3 install -r requirements.txt"


# ApiTestGenerics

pytest --version   # shows where pytest was imported from
pytest --fixtures  # show available builtin function arguments
pytest -h | --help # show help on command line and config file options

pytest -n=(no. of threads)= you can run multiple apis
pytest -v = to run the pytest command