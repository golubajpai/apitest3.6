import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="Api-Test", 
    version="0.0.1",
    author="Priyam Bajpai",
    author_email="priyambajpai302@gmail.com",
    description="A package to test apis",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/golubajpai/apitest3.6",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)

